using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public float speed = 20.0f;
    public float turnSpeed = 20.0f;
    public float horizontalInput;
    public float forwardInput;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // mover o veiculo
        // transform.Translate(0, 0, 1);
        // transform.Translate(Vector3.forward);
        horizontalInput = Input.GetAxis("Horizontal"); // salva o movimento da seta do teclado como movimento no eixo x
        forwardInput = Input.GetAxis("Vertical");
        transform.Translate(Vector3.forward * speed * Time.deltaTime); // ir para frente
        //transform.Translate(Vector3.right * turnSpeed * horizontalInput * Time.deltaTime); //ir para o lado
        transform.Rotate(Vector3.up, turnSpeed * horizontalInput * Time.deltaTime); 
    
    }
}
